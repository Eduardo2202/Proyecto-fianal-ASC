
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Eduardo Soto
 */
public class cls_conexion {
    private static final String DRIVER ="org.sqlite.JDBC";
    private static final String USER = "sa";
    private static final String PASSWORD = " ";
    private static final String URL = "jdbc:sqlite:C:\\ah\\line.db";
    private Connection CN;
    
    public cls_conexion(){
    CN=null;
    }
    
    public Connection getConnection(){
    try{
       Class.forName(DRIVER);
       CN=DriverManager.getConnection(URL,USER,PASSWORD);
    }catch(ClassNotFoundException | SQLException ex){
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Errorrrr" , JOptionPane.ERROR_MESSAGE);
        System.exit(0);
    }
    return CN;
    }
    
    public void close(){
    try{
        CN.close();
    }catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Errorrrr" , JOptionPane.ERROR_MESSAGE);
    }
} 
    
}
