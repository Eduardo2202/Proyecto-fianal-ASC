
package logica;

import conexion.cls_conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Eduardo Soto
 */
public class cls_factura2 {
    
    private final String select = "SELECT * FROM CLIENTE";
    private PreparedStatement PS1;
    private DefaultTableModel DT1;   
    private ResultSet RS1;
    private final cls_conexion CN1;
    
    
    public cls_factura2(){
        PS1=null;        
        CN1= new cls_conexion();       
        
    }
    
    private DefaultTableModel setTitulos1(){
        DT1 = new DefaultTableModel();
        DT1.addColumn("RFC");
        DT1.addColumn("NOMBRE");
        DT1.addColumn("APELLIDO PATERNO");
        DT1.addColumn("EMAIL");        
        return DT1;
    }
    
    public DefaultTableModel getDatos1(){
        try{
            setTitulos1();
            PS1=CN1.getConnection().prepareStatement(select);
            RS1=PS1.executeQuery();
            Object[] fila = new Object[8];
            while(RS1.next()){
                fila[0]=RS1.getString(1);
                fila[1]=RS1.getString(2);
                fila[2]=RS1.getString(3);
                fila[3]=RS1.getString(4);                
                DT1.addRow(fila);
            }
        }catch(SQLException e){
            System.out.println("Error al listar los datos..." + e.getMessage());
            
        }finally{
            PS1=null;
            RS1=null;
            CN1.close();
        }
        return DT1;
    }
    
    public DefaultTableModel getDato1(int crt, String prm){
        String SQL;
        if(crt == 0){
            SQL="SELECT * FROM cliente WHERE nombre = " + prm;
        }else{
            SQL="SELECT * FROM cliente WHERE rfc LIKE '" + prm + "%'";
        }        
        try{
            setTitulos1();
            PS1=CN1.getConnection().prepareStatement(SQL);
            RS1=PS1.executeQuery();
            Object[] fila = new Object[8];
            while(RS1.next()){
                fila[0]=RS1.getString(1);
                fila[1]=RS1.getString(2);
                fila[2]=RS1.getString(3);
                fila[3]=RS1.getString(4);
                DT1.addRow(fila);
            }
        }catch(SQLException e){
            System.out.println("Error al listar los datos..." + e.getMessage());
            
        }finally{
            PS1=null;
            RS1=null;
            CN1.close();
        }
        return DT1;
    }
    
    
}
