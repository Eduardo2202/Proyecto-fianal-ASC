
package logica;

import conexion.cls_conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Eduardo Soto
 */
public class cls_factura {
    
    private final String select = "SELECT * FROM TICKET";
    private PreparedStatement PS;
    private DefaultTableModel DT,DT1;   
    private ResultSet RS;
    private final cls_conexion CN; 
        
    public cls_factura(){
        PS=null;        
        CN= new cls_conexion();       
        
    }
    
   
    
    private DefaultTableModel setTitulos(){
        DT = new DefaultTableModel();
        DT.addColumn("NUMERO");
        DT.addColumn("FOLIO");
        DT.addColumn("UNIDAD");
        DT.addColumn("DESCRIPCION");
        DT.addColumn("PRECIO");
        DT.addColumn("DESCUENTO");
        DT.addColumn("TOTAL");
        DT.addColumn("RFC");
        return DT;
    }
    
    public DefaultTableModel getDatos(){
        try{
            setTitulos();
            PS=CN.getConnection().prepareStatement(select);
            RS=PS.executeQuery();
            Object[] fila = new Object[8];
            while(RS.next()){
                fila[0]=RS.getInt(1);
                fila[1]=RS.getString(2);
                fila[2]=RS.getString(3);
                fila[3]=RS.getString(4);
                fila[4]=RS.getFloat(5);
                fila[5]=RS.getFloat(6);
                fila[6]=RS.getFloat(7);
                fila[7]=RS.getString(8);
                DT.addRow(fila);
            }
        }catch(SQLException e){
            System.out.println("Error al listar los datos..." + e.getMessage());
            
        }finally{
            PS=null;
            RS=null;
            CN.close();
        }
        return DT;
    }
    
    
    
    public DefaultTableModel getDato(int crt, String prm){
        String SQL;
        if(crt == 0){
            SQL="SELECT * FROM ticket WHERE folio = " + prm;
        }else{
            SQL="SELECT * FROM ticket WHERE rfc LIKE '" + prm + "%'";
        }        
        try{
            setTitulos();
            PS=CN.getConnection().prepareStatement(SQL);
            RS=PS.executeQuery();
            Object[] fila = new Object[8];
            while(RS.next()){
                fila[0]=RS.getInt(1);
                fila[1]=RS.getString(2);
                fila[2]=RS.getString(3);
                fila[3]=RS.getString(4);
                fila[4]=RS.getFloat(5);
                fila[5]=RS.getFloat(6);
                fila[6]=RS.getFloat(7);
                fila[7]=RS.getString(8);
                DT.addRow(fila);
            }
        }catch(SQLException e){
            System.out.println("Error al listar los datos..." + e.getMessage());
            
        }finally{
            PS=null;
            RS=null;
            CN.close();
        }
        return DT;
    }
}
