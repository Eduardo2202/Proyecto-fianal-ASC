
package factura;


import formulario.frm_factura; 
/**
 *
 * @author Eduardo Soto
 */
public class cls_Main {
    
    public static void main(String [] args){
        
        frm_factura FM = new frm_factura();
        
        FM.setVisible(true); 
        
        
    }
    
}
