CREATE TABLE CLIENTE
(
	rfc varchar(15) NOT NULL,
	nombre varchar(30) NOT NULL,
	apellido_p varchar(30) NOT NULL,
	email varchar(35) NOT NULL,
	CONSTRAINT pk_rfc PRIMARY KEY (rfc)
);

CREATE TABLE TICKET
(
	num_detalle numeric NOT NULL,
	folio varchar(30) NOT NULL, 
	unidad_med varchar(25) NOT NULL,
	descripcion varchar(40) NOT NULL,
	precio decimal(10,5) NOT NULL,
	descuento decimal(10,5) NOT NULL,
	total decimal(10,5) NOT NULL,
	rfc varchar(15) NOT NULL,
	CONSTRAINT pk_num_detalle PRIMARY KEY (num_detalle),
	CONSTRAINT fk_rfc FOREIGN KEY (rfc) REFERENCES cliente(rfc)
);


INSERT INTO CLIENTE VALUES ('paonava082298','pao','nava', 'paonava@hotmail.com');
INSERT INTO CLIENTE VALUES ('edusoto020290','lalo','soto','lalo02@hotmail.com');
INSERT INTO CLIENTE VALUES ('karenso300591','karen','sosa','krnA@hotmail.com');
INSERT INTO CLIENTE VALUES ('sosags080868','silvia','sosa','ssgA@hotmail.com');



INSERT INTO ticket VALUES (01, 'TRG015269', '1 pieza', 'camisa de dama rosa', '299.00', '170.00', '129.00','paonava082298' );
INSERT INTO ticket VALUES (02, 'TRG015269', '1 pieza', 'pantalon niña walk', '179.00', '0.00', '179.00','paonava082298' );
INSERT INTO ticket VALUES (03, 'TRG015269', '1 pieza', 'blusa niña viena', '69.00', '0.00', '69.00','paonava082298' );
INSERT INTO ticket VALUES (04, 'TRG015269', '1 pieza', 'blusa niña sofie', '69.00', '0.00', '69.00','paonava082298' );
INSERT INTO ticket VALUES (05, 'TRG015269', '1 pieza', 'blusa niña bryce', '269.00', '140.00', '129.00','paonava082298' );


INSERT INTO ticket VALUES (06, 'TRG181403', '1 pieza', 'pantalon caballero 0718', '349.00', '170.00', '179.00','karenso300591' );
INSERT INTO ticket VALUES (07, 'TRG181403', '1 pieza', 'pantalon caballero faty', '399.00', '220.00', '179.00','karenso300591' );
INSERT INTO ticket VALUES (08, 'TRG181403', '1 pieza', 'blusa dama fakus', '149.00', '0.00', '149.00','karenso300591' );
INSERT INTO ticket VALUES (09, 'TRG181403', '1 pieza', 'blusa dama capal', '149.00', '0.00', '149.00','karenso300591' );
INSERT INTO ticket VALUES (10, 'TRG181403', '1 pieza', 'playera caballero roobi', '139.00', '0.00', '139.00','karenso300591' );
INSERT INTO ticket VALUES (11, 'TRG181403', '1 pieza', 'playera caballero varii', '149.00', '0.00', '149.00','karenso300591' );
INSERT INTO ticket VALUES (12, 'TRG181403', '1 pieza', 'playera caballero ferru', '149.00', '0.00', '149.00','karenso300591' );
INSERT INTO ticket VALUES (13, 'TRG181403', '1 pieza', 'blusa niña stop', '99.00', '0.00', '99.00','karenso300591' );


INSERT INTO ticket VALUES (14, 'TRI180338', '1 pieza', 'blusa dama peyi', '139.00', '0.00', '139.00','edusoto020290' );
INSERT INTO ticket VALUES (15, 'TRI180338', '1 pieza', 'blusa dama perl', '139.00', '0.00', '139.00','edusoto020290' );
INSERT INTO ticket VALUES (16, 'TRI180338', '1 pieza', 'blusa dama burbu', '149.00', '0.00', '149.00','edusoto020290' );
INSERT INTO ticket VALUES (17, 'TRI180338', '1 pieza', 'pantalon caballero maddi', '339.00', '220.00', '179.00','edusoto020290' );
INSERT INTO ticket VALUES (18, 'TRI180338', '1 pieza', 'camisa caballero', '249.00', '0.00', '249.00','edusoto020290' );
INSERT INTO ticket VALUES (19, 'TRI180338', '1 pieza', 'pantalon caballero dogyy', '349.00', '170.00', '179.00','edusoto020290' );
INSERT INTO ticket VALUES (20, 'TRI180338', '1 pieza', 'playera zeus', '69.00', '0.00', '69.00','edusoto020290' );
INSERT INTO ticket VALUES (21, 'TRI180338', '1 pieza', 'pantalon caballero nair', '349.00', '170.00', '179.00','edusoto020290' );
INSERT INTO ticket VALUES (22, 'TRI180338', '1 pieza', 'pantalon caballero joggy', '349.00', '170.00', '179.00','edusoto020290' );

INSERT INTO ticket VALUES (22, 'TRI180338', '1 pieza', 'pantalon caballero joggy', '349.00', '170.00', '179.00','edusoto020290' );




 




